To load data into database i have selected to make use of spring framework.
Spring batch provides the ability to scale the behaviour to different source like
1. If input source type changed from flatfile to different source like sftp, database, we just have to change the reader part.
2. If there is any change in target database, say from mysql to postgresql, then we have to change the database configurations only. JPA repositories will take care of saving store order into db.
3. We are doing chunk processing to avoid to much load in app if the input csv has millions of record.